//fundamental canvas config and creating a grid for the snake to move on
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const scale = 20; //each snake part is 20x20 pixels
const rows = Math.floor(canvas.height / scale);
const columns = Math.floor(canvas.width / scale);
const scoreDisplay = document.getElementsByClassName("score")[0];
const finalScore = document.getElementsByClassName("finalScore")[0];
const highScoreElement = document.querySelector(".highScores ol");
let score = 0;
let gameplaySpeedMultiplier = 0.05; //increase speed by score * this
let snake = [];
let fruitLocation = {};
let direction = null;
let walls = [];
let highScores = [];

let secondSnake = [];
let secondSnakeDirection = null;
let secondSnakeMoving = false;

function reset() {
  //initial snake spawn point
  snake = [
    { x: scale * 8, y: scale * 5 },
    { x: scale * 7, y: scale * 5 },
    { x: scale * 6, y: scale * 5 },
    { x: scale * 5, y: scale * 5 },
  ];

  fruitLocation = {
    x: scale * 20,
    y: scale * 5,
  };

  score = 0;
  scoreDisplay.innerHTML = `Score: ${score}`;

  highScores = JSON.parse(localStorage.getItem("highScores")) || [];

  highScoreElement.innerHTML = `
  <li>${highScores[0] || ""}</li>
  <li>${highScores[1] || ""}</li>
  <li>${highScores[2] || ""}</li>
  <li>${highScores[3] || ""}</li>
  <li>${highScores[4] || ""}</li>
  `;

  //initial snake direction upon spawn
  direction = null;
  walls = [];

  //reset second snake
  secondSnake = [];
  secondSnakeDirection = null;
  secondSnakeMoving = false;
}

function drawSnake() {
  ctx.fillStyle = "#FFFFFF";
  for (const segment of snake) {
    ctx.fillRect(segment.x, segment.y, scale, scale);
  }
}

function drawSecondSnake() {
  if (!secondSnakeMoving) return;

  ctx.fillStyle = "#0000FF"; //different color for the second snake
  for (const segment of secondSnake) {
    ctx.fillRect(segment.x, segment.y, scale, scale);
  }
}

window.addEventListener("keydown", (keyPress) => {
  finalScore.style.visibility = "hidden";
  switch (keyPress.key) {
    case "ArrowUp":
      if (direction != "down") direction = "up";
      break;
    case "ArrowDown":
      if (direction != "up") direction = "down";
      break;
    case "ArrowLeft":
      if (direction != "right" && direction != null) direction = "left";
      break;
    case "ArrowRight":
      if (direction != "left") direction = "right";
      break;
  }
});

function moveSnake() {
  let head = { x: snake[0].x, y: snake[0].y };
  switch (direction) {
    case "up":
      head.y -= scale;
      break;
    case "down":
      head.y += scale;
      break;
    case "left":
      head.x -= scale;
      break;
    case "right":
      head.x += scale;
      break;
    case null:
      return;
  }
  //escape function if failstate is met
  if (checkFailState(head)) {
    return;
  }
  //increment score and add segment if snake collides with fruit
  if (head.x === fruitLocation.x && head.y === fruitLocation.y) {
    fruitLocation.x = null;
    fruitLocation.y = null;
    score += 10;
    scoreDisplay.innerHTML = `Score: ${score}`;
    if (score % 100 === 0 && !secondSnakeMoving) {
      spawnSecondSnake();
    }
  } else {
    snake.pop();
  }
  snake.unshift(head);
}

function createFruit() {
  if (fruitLocation.x === null || fruitLocation.y === null) {
    do {
      fruitLocation.x =
        scale * Math.floor((Math.random() * canvas.width) / scale);
      fruitLocation.y =
        scale * Math.floor((Math.random() * canvas.height) / scale);
    } while (checkForExistingElements(fruitLocation));
  }
  ctx.fillStyle = "#d60202";
  ctx.fillRect(fruitLocation.x, fruitLocation.y, scale, scale);
}

function checkFailState(head) {
  if (
    head.x >= canvas.width ||
    head.x < 0 ||
    head.y >= canvas.height ||
    head.y < 0 ||
    checkForExistingElements(head)
  ) {
    managePostGameScores();
    return true;
  }
}

function createWall() {
  if (score / 50 >= walls.length + 1 && score > 0) {
    let newWall = { x: null, y: null };
    do {
      newWall.x = scale * Math.floor((Math.random() * canvas.width) / scale);
      newWall.y = 0;
    } while (checkForExistingElements(newWall));
    walls.push(newWall);
  }

  ctx.fillStyle = "#818589";
  for (const wall of walls) {
    ctx.fillRect(wall.x, wall.y, scale, scale);
  }
}

function checkForExistingElements(objectToTest) {
  return (
    snake.some(
      (element) => element.x === objectToTest.x && element.y === objectToTest.y,
    ) ||
    walls.some(
      (element) => element.x === objectToTest.x && element.y === objectToTest.y,
    ) ||
    secondSnake.some(
      (element) => element.x === objectToTest.x && element.y === objectToTest.y,
    )
  );
}

function managePostGameScores() {
  finalScore.innerHTML = `Your Score: ${score}`;
  finalScore.style.visibility = "visible";
  highScores.push(score);
  highScores.sort((a, b) => b - a);
  if (highScores.length > 5) {
    highScores.pop();
  }
  localStorage.setItem("highScores", JSON.stringify(highScores));
  reset();
}

function moveSecondSnake() {
  if (!secondSnakeMoving) return;

  const directions = ["up", "down", "left", "right"];
  let newDirection;
  do {
    newDirection = directions[Math.floor(Math.random() * directions.length)];
  } while (
    (newDirection === "up" && secondSnakeDirection === "down") ||
    (newDirection === "down" && secondSnakeDirection === "up") ||
    (newDirection === "left" && secondSnakeDirection === "right") ||
    (newDirection === "right" && secondSnakeDirection === "left")
  );

  secondSnakeDirection = newDirection;

  let head = { x: secondSnake[0].x, y: secondSnake[0].y };
  switch (secondSnakeDirection) {
    case "up":
      head.y -= scale;
      break;
    case "down":
      head.y += scale;
      break;
    case "left":
      head.x -= scale;
      break;
    case "right":
      head.x += scale;
      break;
  }

  //check collision with walls, fruit, and player snake
  if (
    !(
      head.x >= canvas.width ||
      head.x < 0 ||
      head.y >= canvas.height ||
      head.y < 0 ||
      checkForExistingElements(head)
    )
  ) {
    secondSnake.pop();
    secondSnake.unshift(head);
  } else if (
    snake.some(
      (element) => element.x === head.x && element.y === head.y,
    )
  ) {
    secondSnake = [];
    secondSnakeMoving = false;
    secondSnakeDirection = null;
  }
}

function manageWalls() {
  for (const wall of walls) {
    if (wall.y < wall.x) {
      wall.y += scale;
    }
  }
}

function spawnSecondSnake() {
  secondSnake = [
    { x: scale * 10, y: scale * 10 },
    { x: scale * 9, y: scale * 10 },
    { x: scale * 8, y: scale * 10 },
  ];
  secondSnakeMoving = true;
  secondSnakeDirection = "right"; //initial direction
}

function update() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  moveSnake();
  moveSecondSnake();
  drawSnake();
  drawSecondSnake();
  createFruit();
  createWall();
  manageWalls();

  //calculate speed based on score and stop score scaling lower than 80
  let speed = 100 - Math.min(Math.floor(score / 20), 20);

  setTimeout(update, speed);
}

reset();
update();
